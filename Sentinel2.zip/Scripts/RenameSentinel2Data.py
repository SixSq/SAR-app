#------------------------------------------------------------------------------
# Copyright 2013 Esri
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#-------------------------------------------------------------------------------
# Name: RenameSentinal2Data.py
# Description: Rename folders names to reduce file names by splitting existing folder name like
#               "S2A_OPER_PRD_MSIL1C_PDMC_20151203T110702_R048_V20151203T060426_20151203T060426.SAFE" to
#               "S2A_OPER_PRD_MSIL1C_PDMC_20151203T110702"
# Version: 20151207
#Required Arguments : test data folder eg.\\shastorage3\RasterData\SensorData\Sentinel-2\S2A_OPER_PRD_MSIL1C_PDMC_20151203T110702_R048_V20151203T060426_20151203T060426.SAFE\
#                     or folder containing eg. \\shastorage3\RasterData\SensorData\Sentinel-2\TestData\
#Notes : used to reduce absolute length of folder path to less than 256 characters
#        Change parent_folder_path to the input folder to be renamed
#-------------------------------------------------------------------------------

import os,sys
def main():
    if len(sys.argv) != 2:
        print (" number of inputs are invalid")
        print (" <path to the input folder>")
        sys.exit()
    parent_folder_path = sys.argv[1]
    splt=[]
    if len(parent_folder_path)>30:
        try:
            for path, subdirs, files in os.walk(parent_folder_path):
                for f in subdirs:
                    if (f == 'GRANULE'):
                        if path.count('_')>4:
                            splt=path.split("\\")
                            rename_directory_path=""
                            for i in range(len(splt)-1):
                                rename_directory_path   = rename_directory_path+splt[i] + "\\"
                            rename_folder=splt[-1]
                            a=rename_folder.split("/")[-1].split("_")
                            try:
                                rename_folder=a[0] + "_" + a[1] + "_" +a[2] + "_" +a[3] + "_" + a[4] + "_" + a[5]
                                os.rename(os.path.join(path),os.path.join(rename_directory_path,rename_folder))
                            except:
                                print "failed to rename a folder :" + str(path)

                            print "Renaming {} with {}" .format(os.path.join(path),os.path.join(rename_directory_path,rename_folder))
                    else:
                        pass
        except:
            pass
if __name__ == '__main__':
    main()


